import { useState, useEffect, useRef, useCallback } from "react";
import { motion, AnimatePresence, LayoutGroup } from "framer-motion";
import {
  X,
  ChevronLeft,
  CalendarDays,
  Clock,
  Users,
  User,
  Check,
  Send,
  ArrowRight,
  Shield,
  Sparkles,
} from "lucide-react";
import { GuestSelector } from "./GuestSelector";
import type { GuestCount } from "./GuestSelector";
import { ArrivalDateTimePicker } from "./ArrivalDateTimePicker";
import { TermsModal } from "./TermsModal";
import { cn } from "../../lib/cn";
import { images } from "../../lib/images";
import { createReservation } from "../../services/api/reservations";
import {
  checkAvailability,
  fetchUpcomingAvailability,
  type AvailabilityReservation,
} from "../../services/api/availability";
import type { Reservation, ReservationStatus } from "../../lib/reservationData";
import {
  combineArrivalDatetime,
  computeCheckout,
  formatArrivalLabel,
  formatCheckoutLabel,
  isKrib1,
  hasFixedCheckin,
  getFixedCheckinTime,
  KRIB1_STANDARD_CAPACITY,
  computeTotalAdditionalCharges,
} from "../../lib/bookingTime";
import { getUnavailableDates, isBlockedArrival } from "../../lib/availability";

interface PropertyInfo {
  id: string;
  name: string;
  priceDetails: { perNight: string; rateType: string };
  maxGuests: number;
  partyFeeLabel?: string;
}

interface BookingExperienceProps {
  isOpen: boolean;
  onClose: () => void;
  property: PropertyInfo;
  partyFeeActive?: boolean;
  partyFeeAmount?: number;
  onPartyFeeToggle?: (active: boolean) => void;
  initialArrivalDate?: string | null;
}

type Step = 1 | 2 | 3 | 4;
type SubmitState = "idle" | "submitting" | "success";

const STEP_COUNT = 4;

const overlayVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { duration: 0.35, ease: [0.22, 1, 0.36, 1] as const },
  },
  exit: {
    opacity: 0,
    transition: { duration: 0.25, ease: [0.22, 1, 0.36, 1] as const },
  },
};

const panelDesktopVariants = {
  hidden: { opacity: 0, y: 24, scale: 0.98 },
  visible: {
    opacity: 1,
    y: 0,
    scale: 1,
    transition: { duration: 0.45, ease: [0.22, 1, 0.36, 1] as const },
  },
  exit: {
    opacity: 0,
    y: 16,
    scale: 0.98,
    transition: { duration: 0.25, ease: [0.22, 1, 0.36, 1] as const },
  },
};

const panelMobileVariants = {
  hidden: { y: "100%" },
  visible: {
    y: 0,
    transition: { type: "spring" as const, stiffness: 320, damping: 34 },
  },
  exit: {
    y: "100%",
    transition: { duration: 0.3, ease: [0.22, 1, 0.36, 1] as const },
  },
};

const stepContentVariants = {
  enter: (direction: number) => ({
    x: direction > 0 ? 40 : -40,
    opacity: 0,
  }),
  center: {
    x: 0,
    opacity: 1,
    transition: { duration: 0.35, ease: [0.22, 1, 0.36, 1] as const },
  },
  exit: (direction: number) => ({
    x: direction > 0 ? -40 : 40,
    opacity: 0,
    transition: { duration: 0.2, ease: [0.22, 1, 0.36, 1] as const },
  }),
};

function parsePrice(priceStr: string): number {
  return parseInt(priceStr.replace(/[^0-9]/g, ""), 10);
}

function formatPrice(amount: number): string {
  return "₱" + amount.toLocaleString("en-PH");
}

function getVillaImage(villaId: string): string {
  if (villaId === "krib-2") return images.krib2Exterior;
  return images.krib1;
}

const STEP_META: {
  label: string;
  icon: typeof CalendarDays;
  heading: string;
  subheading: string;
}[] = [
  {
    label: "Date",
    icon: CalendarDays,
    heading: "Choose your stay date",
    subheading:
      "Select your preferred arrival date and time. Your stay includes a full 21-hour experience.",
  },
  {
    label: "Guests",
    icon: Users,
    heading: "Who's joining your stay?",
    subheading: "Tell us who will be enjoying the villa.",
  },
  {
    label: "Details",
    icon: User,
    heading: "A few details about you",
    subheading: "So we can prepare for your arrival.",
  },
  {
    label: "Review",
    icon: Check,
    heading: "Review your reservation",
    subheading: "Everything look good? Submit your request.",
  },
];

export function BookingExperience({
  isOpen,
  onClose,
  property,
  partyFeeActive,
  partyFeeAmount,
  onPartyFeeToggle,
  initialArrivalDate,
}: BookingExperienceProps) {
  const [step, setStep] = useState<Step>(1);
  const [direction, setDirection] = useState(1);
  const [submitState, setSubmitState] = useState<SubmitState>("idle");
  const [reservationId, setReservationId] = useState("");

  const [arrivalDate, setArrivalDate] = useState<string | null>(null);
  const [arrivalTime, setArrivalTime] = useState<string | null>(null);
  const [guests, setGuests] = useState<GuestCount>({
    adults: 2,
    children: 0,
    infants: 0,
    pets: 0,
  });
  const [isParty, setIsParty] = useState(false);
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [message, setMessage] = useState("");
  const [consentAccepted, setConsentAccepted] = useState(false);
  const [termsOpen, setTermsOpen] = useState(false);
  const [termsSection, setTermsSection] = useState<"terms" | "privacy">(
    "terms",
  );
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitError, setSubmitError] = useState("");
  const [availabilityReservations, setAvailabilityReservations] = useState<
    AvailabilityReservation[]
  >([]);
  const [availabilityLoading, setAvailabilityLoading] = useState(false);
  const [availabilityError, setAvailabilityError] = useState("");
  const submitErrorRef = useRef<HTMLDivElement>(null);

  const panelRef = useRef<HTMLDivElement>(null);
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const previousFocusRef = useRef<HTMLElement | null>(null);
  const consentRowRef = useRef<HTMLDivElement>(null);
  const termsLinkRef = useRef<HTMLButtonElement>(null);
  const privacyLinkRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    if (isOpen) {
      previousFocusRef.current = document.activeElement as HTMLElement;
      setStep(1);
      setDirection(1);
      setSubmitState("idle");
      setReservationId("");
      setArrivalDate(initialArrivalDate ?? null);
      setArrivalTime(null);
      setGuests({ adults: 2, children: 0, infants: 0, pets: 0 });
      setIsParty(false);
      setFullName("");
      setEmail("");
      setPhone("");
      setMessage("");
      setConsentAccepted(false);
      setTermsOpen(false);
      setErrors({});
      setSubmitError("");
    } else {
      previousFocusRef.current?.focus();
    }
  }, [isOpen]);

  const refreshAvailability = useCallback(async () => {
    setAvailabilityLoading(true);
    setAvailabilityError("");
    try {
      const reservations = await fetchUpcomingAvailability(property.id);
      setAvailabilityReservations(reservations);
    } catch {
      setAvailabilityReservations([]);
      setAvailabilityError(
        "Availability could not be checked. Please try again.",
      );
    } finally {
      setAvailabilityLoading(false);
    }
  }, [property.id]);

  useEffect(() => {
    if (isOpen) void refreshAvailability();
  }, [isOpen, refreshAvailability]);

  useEffect(() => {
    if (!isOpen) return;
    const scrollY = window.scrollY;
    const scrollbarWidth =
      window.innerWidth - document.documentElement.clientWidth;
    document.body.style.position = "fixed";
    document.body.style.top = `-${scrollY}px`;
    document.body.style.left = "0";
    document.body.style.right = "0";
    document.body.style.width = "100%";
    document.body.style.paddingRight = `${scrollbarWidth}px`;
    document.body.style.overflow = "hidden";

    return () => {
      document.body.style.position = "";
      document.body.style.top = "";
      document.body.style.left = "";
      document.body.style.right = "";
      document.body.style.width = "";
      document.body.style.paddingRight = "";
      document.body.style.overflow = "";
      window.scrollTo(0, scrollY);
    };
  }, [isOpen]);

  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape" && submitState === "idle" && !termsOpen) onClose();
    };
    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [isOpen, onClose, submitState, termsOpen]);

  const basePrice = parsePrice(property.priceDetails.perNight);
  const totalGuests = guests.adults + guests.children;
  const isKrib1Villa = isKrib1(property.id);
  const hasFixedCheckinVilla = hasFixedCheckin(property.id);
  const isOverCapacity = isKrib1Villa && totalGuests > KRIB1_STANDARD_CAPACITY;
  const isPartyValid = isParty && isKrib1Villa;
  const fixedCheckinTime = hasFixedCheckinVilla
    ? (getFixedCheckinTime(property.id) ?? undefined)
    : undefined;
  const { additionalGuestFee } = computeTotalAdditionalCharges(
    property.id,
    totalGuests,
    isPartyValid,
  );
  const partyFeeRate = partyFeeAmount ?? 5000;
  const partyFee = isPartyValid ? partyFeeRate : 0;
  const total = basePrice + additionalGuestFee + partyFee;

  // For KRiB 1 and KRiB 2: auto-set fixed arrival time when a date is selected
  const effectiveArrivalTime = hasFixedCheckinVilla
    ? getFixedCheckinTime(property.id)!
    : arrivalTime;
  const unavailableDates = getUnavailableDates(
    availabilityReservations,
    property.id,
  );
  const isTimeUnavailable = (time: string) =>
    !!arrivalDate &&
    isBlockedArrival(arrivalDate, time, availabilityReservations);

  const goNext = useCallback(() => {
    if (step < STEP_COUNT) {
      setDirection(1);
      setStep((s) => (s + 1) as Step);
      scrollContainerRef.current?.scrollTo({ top: 0, behavior: "smooth" });
    }
  }, [step]);

  const goBack = useCallback(() => {
    if (step > 1) {
      setDirection(-1);
      setStep((s) => (s - 1) as Step);
      scrollContainerRef.current?.scrollTo({ top: 0, behavior: "smooth" });
    }
  }, [step]);

  const goToStep = useCallback(
    (target: Step) => {
      if (target < step) {
        setDirection(-1);
        setStep(target);
        scrollContainerRef.current?.scrollTo({ top: 0, behavior: "smooth" });
      }
    },
    [step],
  );

  const validateStep = (s: Step): boolean => {
    const errs: Record<string, string> = {};
    if (s === 1) {
      if (!arrivalDate) errs.date = "Please select a date";
      if (!hasFixedCheckinVilla && !arrivalTime)
        errs.time = "Please select a time";
    }
    if (s === 3) {
      if (!fullName.trim()) errs.fullName = "Name is required";
      if (!email.trim()) errs.email = "Email is required";
      else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))
        errs.email = "Enter a valid email";
      if (!phone.trim()) errs.phone = "Phone is required";
      else if (!/^[\d\s+\-()]{7,20}$/.test(phone))
        errs.phone = "Enter a valid phone number";
      if (!consentAccepted)
        errs.consent =
          "Please review and agree to the Terms & Conditions and Privacy Policy before continuing.";
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleNext = () => {
    if (validateStep(step)) goNext();
  };

  const handleSubmit = async () => {
    if (!validateStep(3)) return;
    setSubmitError("");
    setSubmitState("submitting");

    const arrivalDatetime = combineArrivalDatetime(
      arrivalDate!,
      effectiveArrivalTime!,
    );
    const checkoutDatetime = computeCheckout(arrivalDatetime);

    try {
      const available = await checkAvailability(
        property.id,
        arrivalDatetime,
        checkoutDatetime,
      );
      if (!available) {
        setSubmitState("idle");
        setSubmitError(
          "This date is no longer available. Another reservation has already been made for this schedule. Please select another date.",
        );
        await refreshAvailability();
        return;
      }
    } catch {
      setSubmitState("idle");
      setSubmitError(
        "Unable to verify availability. Please check your connection and try again.",
      );
      return;
    }

    const { data, error } = await createReservation({
      villa_id: property.id,
      arrival_datetime: arrivalDatetime,
      full_name: fullName,
      email,
      phone,
      special_requests: message,
      adults: guests.adults,
      children: guests.children,
      infants: guests.infants,
      pets: guests.pets,
      is_party: isPartyValid,
      terms_accepted: consentAccepted,
      privacy_accepted: consentAccepted,
    });

    if (error || !data) {
      setSubmitState("idle");
      if (error?.code === "DATE_UNAVAILABLE") {
        setSubmitError(
          "This date is no longer available. Another reservation has already been made for this schedule. Please select another date.",
        );
        await refreshAvailability();
      } else {
        setSubmitError(
          error?.message ??
            "Unable to submit your reservation. Please try again.",
        );
      }
      setTimeout(() => {
        submitErrorRef.current?.scrollIntoView({
          behavior: "smooth",
          block: "center",
        });
      }, 50);
      return;
    }

    const r = data.reservation;
    const newId = r.reference_code;
    setReservationId(newId);

    const reservationData: Reservation = {
      id: newId,
      email: r.guest.email,
      guestName: r.guest.full_name,
      villaId: r.villa.slug,
      villaName: r.villa.name,
      maxGuests: property.maxGuests,
      checkIn: r.arrival_datetime,
      checkOut: r.checkout_datetime,
      arrivalDatetime: r.arrival_datetime,
      checkoutDatetime: r.checkout_datetime,
      guests: {
        adults: guests.adults,
        children: guests.children,
        infants: guests.infants,
        pets: guests.pets,
      },
      createdAt: r.created_at.slice(0, 10),
      status: r.status as ReservationStatus,
      baseRate: basePrice,
      additionalGuestFee: r.additional_guest_fee ?? 0,
      partyFee: r.party_fee ?? 0,
      totalAmount: r.total_amount ?? total,
      isParty: r.is_party ?? false,
      confirmationNumber: r.reference_code,
      message: r.special_requests,
    };

    sessionStorage.setItem(
      "krib_last_reservation",
      JSON.stringify({ id: newId, email }),
    );
    sessionStorage.setItem(
      "krib_last_reservation_full",
      JSON.stringify(reservationData),
    );
    setSubmitState("success");
  };

  const handleConsentChange = (checked: boolean) => {
    setConsentAccepted(checked);
    if (checked) {
      setErrors((prev) => {
        if (!prev.consent) return prev;
        const next = { ...prev };
        delete next.consent;
        return next;
      });
    }
  };

  const openReview = useCallback((reviewSection: "terms" | "privacy") => {
    setTermsSection(reviewSection);
    setTermsOpen(true);
  }, []);

  const arrivalDatetime =
    arrivalDate && effectiveArrivalTime
      ? combineArrivalDatetime(arrivalDate, effectiveArrivalTime)
      : null;
  const checkoutDatetime = arrivalDatetime
    ? computeCheckout(arrivalDatetime)
    : null;
  const hasArrival = !!arrivalDatetime;
  const meta = STEP_META[step - 1];

  const summaryContent = (
    <div className="flex flex-col h-full">
      <div className="relative h-44 lg:h-52 overflow-hidden shrink-0">
        <img
          src={getVillaImage(property.id)}
          alt={property.name}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-linear-to-t from-black/50 via-black/10 to-transparent" />
        <div className="absolute bottom-4 left-5 right-5">
          <p className="font-body text-[10px] text-white/60 uppercase tracking-[0.2em] font-semibold mb-1">
            Your Villa
          </p>
          <p className="font-display text-headline-sm text-white">
            {property.name}
          </p>
        </div>
      </div>

      <div className="flex-1 p-5 lg:p-6 space-y-0">
        <SummaryItem
          label="Stay Duration"
          value="21 Hours"
          icon={<Clock size={14} className="text-on-surface-variant/50" />}
        />

        {hasArrival && (
          <>
            <SummaryItem
              label="Arrival"
              value={formatArrivalLabel(arrivalDatetime!)}
            />
            <SummaryItem
              label="Checkout"
              value={formatCheckoutLabel(checkoutDatetime!)}
              valueClassName="text-primary"
            />
          </>
        )}

        {totalGuests > 0 && (
          <SummaryItem
            label="Guests"
            value={`${totalGuests} ${totalGuests === 1 ? "Guest" : "Guests"}`}
          />
        )}

        <div className="h-px bg-outline-variant/40 my-4" />

        <div className="flex justify-between items-center">
          <span className="font-body text-sm text-on-surface-variant">
            Base Rate
          </span>
          <span className="font-body text-sm text-on-surface font-medium">
            {formatPrice(basePrice)}
          </span>
        </div>

        {isOverCapacity && (
          <div className="flex items-center justify-between py-1">
            <span className="font-body text-sm text-on-surface-variant">
              Additional guests ({totalGuests - KRIB1_STANDARD_CAPACITY} × ₱200)
            </span>
            <span className="font-body text-sm text-on-surface font-medium">
              {formatPrice(additionalGuestFee)}
            </span>
          </div>
        )}

        {onPartyFeeToggle && hasFixedCheckinVilla && (
          <button
            type="button"
            onClick={() => {
              const next = !isParty;
              setIsParty(next);
              onPartyFeeToggle(next);
            }}
            className={cn(
              "flex w-full items-center justify-between gap-4 py-3 transition-colors duration-200 cursor-pointer",
              "hover:text-primary",
              "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/30 focus-visible:ring-offset-2",
            )}
            role="switch"
            aria-checked={isParty}
            aria-label="Toggle party fee"
          >
            <div className="flex items-center gap-3 shrink-0">
              <div
                className={cn(
                  "relative inline-flex h-6 w-11 items-center rounded-full transition-colors duration-300 ease-out shrink-0",
                  isParty ? "bg-primary" : "bg-outline/30",
                )}
              >
                <motion.span
                  animate={{ x: isParty ? 20 : 0 }}
                  transition={{
                    type: "spring",
                    stiffness: 520,
                    damping: 32,
                    mass: 0.7,
                  }}
                  className="absolute left-1 inline-block h-4 w-4 rounded-full bg-white shadow-sm"
                />
              </div>
              <span
                className={cn(
                  "font-body text-sm font-medium",
                  isParty ? "text-on-surface" : "text-on-surface-variant",
                )}
              >
                Party fee
              </span>
            </div>
            <motion.span
              key={isParty ? "on" : "off"}
              initial={{ opacity: 0, x: 4 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.2, ease: "easeOut" }}
              className={cn(
                "font-body text-sm font-medium tabular-nums shrink-0",
                isParty ? "text-primary" : "text-on-surface-variant/60",
              )}
            >
              {isParty ? (
                formatPrice(partyFeeRate)
              ) : (
                <span className="text-on-surface-variant/40">₱5,000</span>
              )}
            </motion.span>
          </button>
        )}

        {!hasFixedCheckinVilla && onPartyFeeToggle && (
          <button
            type="button"
            onClick={() => onPartyFeeToggle(!partyFeeActive!)}
            className={cn(
              "flex w-full items-center justify-between gap-4 py-3 rounded-lg border transition-colors duration-200 cursor-pointer",
              partyFeeActive
                ? "bg-primary/5 border-primary/20"
                : "bg-surface-container-low border-outline-variant/30 hover:bg-surface-container hover:border-primary/20",
              "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/30 focus-visible:ring-offset-2",
            )}
            role="switch"
            aria-checked={!!partyFeeActive}
            aria-label="Toggle party fee"
          >
            <div className="flex items-center gap-3 shrink-0">
              <div
                className={cn(
                  "relative inline-flex h-6 w-11 items-center rounded-full transition-colors duration-300 ease-out shrink-0",
                  partyFeeActive ? "bg-primary" : "bg-outline/30",
                )}
              >
                <motion.span
                  animate={{ x: partyFeeActive ? 20 : 0 }}
                  transition={{
                    type: "spring",
                    stiffness: 520,
                    damping: 32,
                    mass: 0.7,
                  }}
                  className="absolute left-1 inline-block h-4 w-4 rounded-full bg-white shadow-sm"
                />
              </div>
              <span
                className={cn(
                  "font-body text-sm font-medium",
                  partyFeeActive
                    ? "text-on-surface"
                    : "text-on-surface-variant",
                )}
              >
                Party fee
              </span>
            </div>
            <motion.span
              key={partyFeeActive ? "on" : "off"}
              initial={{ opacity: 0, x: 4 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.2, ease: "easeOut" }}
              className={cn(
                "font-body text-sm font-medium tabular-nums shrink-0",
                partyFeeActive ? "text-primary" : "text-on-surface-variant/60",
              )}
            >
              {partyFeeActive ? (
                formatPrice(partyFeeRate)
              ) : (
                <span className="text-on-surface-variant/40">₱5,000</span>
              )}
            </motion.span>
          </button>
        )}

        {isOverCapacity && (
          <div className="p-3 rounded-lg bg-amber-50 border border-amber-200/60 mt-3">
            <p className="font-body text-[11px] text-amber-800 font-medium">
              More than {KRIB1_STANDARD_CAPACITY} guests requires admin
              approval.
            </p>
          </div>
        )}

        <div className="h-px bg-on-surface/10 my-4" />

        <div className="flex justify-between items-baseline">
          <span className="font-body text-sm font-semibold text-on-surface">
            Total
          </span>
          <LayoutGroup>
            <motion.span
              key={total}
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
              className="font-display text-headline-md font-medium text-primary"
            >
              {formatPrice(total)}
            </motion.span>
          </LayoutGroup>
        </div>
      </div>

      <div className="p-5 lg:p-6 pt-0 lg:pt-0">
        {submitState === "idle" && step < STEP_COUNT && (
          <button
            onClick={handleNext}
            className={cn(
              "w-full py-4 rounded-full font-body text-xs font-semibold uppercase tracking-[0.14em]",
              "bg-primary text-on-primary",
              "shadow-[0_4px_16px_rgba(0,71,171,0.2)]",
              "hover:bg-primary-hover hover:shadow-[0_6px_24px_rgba(0,71,171,0.28)]",
              "transition-all duration-300 cursor-pointer",
            )}
          >
            Continue
          </button>
        )}
        {submitState === "idle" && step === STEP_COUNT && (
          <button
            onClick={handleSubmit}
            className={cn(
              "w-full py-4 rounded-full inline-flex items-center justify-center gap-2.5",
              "font-body text-xs font-semibold uppercase tracking-[0.14em]",
              "bg-primary text-on-primary",
              "shadow-[0_4px_16px_rgba(0,71,171,0.2)]",
              "hover:bg-primary-hover hover:shadow-[0_6px_24px_rgba(0,71,171,0.28)]",
              "transition-all duration-300 cursor-pointer",
            )}
          >
            <Send size={14} />
            Request Reservation
          </button>
        )}
        {submitState === "idle" && (
          <div className="flex items-center gap-2 mt-3 justify-center">
            <Shield size={12} className="text-tertiary" />
            <p className="font-body text-[11px] text-on-surface-variant/60">
              No payment until your reservation is approved
            </p>
          </div>
        )}
      </div>
    </div>
  );

  const stepContent = (
    <LayoutGroup>
      <AnimatePresence mode="wait" custom={direction}>
        <motion.div
          key={`step-${step}`}
          custom={direction}
          variants={stepContentVariants}
          initial="enter"
          animate="center"
          exit="exit"
        >
          {step === 1 && (
            <StepDate
              arrivalDate={arrivalDate}
              arrivalTime={arrivalTime}
              onArrivalDateChange={setArrivalDate}
              onArrivalTimeChange={setArrivalTime}
              dateError={errors.date}
              timeError={errors.time}
              fixedTime={fixedCheckinTime}
              fixedTimeLabel={fixedCheckinTime ? "2:00 PM (Fixed)" : undefined}
              unavailableDates={unavailableDates}
              isTimeUnavailable={isTimeUnavailable}
              availabilityLoading={availabilityLoading}
              availabilityError={availabilityError}
            />
          )}
          {step === 2 && (
            <StepGuests
              maxGuests={property.maxGuests}
              villaName={property.name}
              guests={guests}
              onChange={setGuests}
              isKrib1={isKrib1Villa}
            />
          )}
          {step === 3 && (
            <StepDetails
              fullName={fullName}
              onFullNameChange={setFullName}
              email={email}
              onEmailChange={setEmail}
              phone={phone}
              onPhoneChange={setPhone}
              message={message}
              onMessageChange={setMessage}
              consentAccepted={consentAccepted}
              onConsentChange={handleConsentChange}
              onOpenTerms={() => openReview("terms")}
              onOpenPrivacy={() => openReview("privacy")}
              onOpenReview={() => openReview("terms")}
              consentRowRef={consentRowRef}
              termsLinkRef={termsLinkRef}
              privacyLinkRef={privacyLinkRef}
              errors={errors}
            />
          )}
          {step === 4 && (
            <StepReview
              property={property}
              arrivalDatetime={arrivalDatetime}
              checkoutDatetime={checkoutDatetime}
              guests={guests}
              totalGuests={totalGuests}
              fullName={fullName}
              email={email}
              phone={phone}
              message={message}
              basePrice={basePrice}
              isKrib1={isKrib1Villa}
              isParty={isParty}
              additionalGuestFee={additionalGuestFee}
              partyFeeAmount={partyFeeRate}
              total={total}
              submitError={submitError}
              submitErrorRef={submitErrorRef}
            />
          )}
        </motion.div>
      </AnimatePresence>
    </LayoutGroup>
  );

  return (
    <>
      <AnimatePresence>
        {isOpen && (
          <motion.div
            variants={overlayVariants}
            initial="hidden"
            animate="visible"
            exit="exit"
            className="fixed inset-0 z-100"
            onClick={(e) => {
              if (e.target === e.currentTarget && submitState === "idle")
                onClose();
            }}
          >
            <div className="absolute inset-0 bg-black/50 backdrop-blur-[2px]" />

            {/* ─── DESKTOP / TABLET PANEL ─── */}
            <motion.div
              ref={panelRef}
              variants={panelDesktopVariants}
              initial="hidden"
              animate="visible"
              exit="exit"
              className={cn(
                "hidden md:flex flex-col bg-white overflow-hidden",
                "absolute inset-4 lg:inset-6 xl:inset-8",
                "max-w-1280px mx-auto my-auto max-h-[92vh]",
                "shadow-[0_24px_80px_rgba(0,0,0,0.18)]",
              )}
              onClick={(e) => e.stopPropagation()}
            >
              {submitState === "success" ? (
                <SuccessState
                  propertyName={property.name}
                  reservationId={reservationId}
                  onClose={onClose}
                />
              ) : submitState === "submitting" ? (
                <SubmittingState />
              ) : (
                <div className="flex flex-1 min-h-0 overflow-hidden">
                  {/* LEFT — Booking Flow */}
                  <div className="flex-1 flex flex-col min-w-0 min-h-0">
                    {/* Step Header */}
                    <div className="shrink-0 px-8 lg:px-10 pt-7 pb-0">
                      <div className="flex items-center justify-between mb-6">
                        <div className="flex items-center gap-1">
                          {STEP_META.map((m, i) => {
                            const Icon = m.icon;
                            const isCurrent = i + 1 === step;
                            const isDone = i + 1 < step;
                            return (
                              <button
                                key={m.label}
                                onClick={() =>
                                  isDone && goToStep((i + 1) as Step)
                                }
                                className={cn(
                                  "flex items-center gap-2 px-3 py-2 rounded-full transition-all duration-300",
                                  isCurrent
                                    ? "text-primary"
                                    : isDone
                                      ? "text-on-surface-variant/60 hover:text-primary cursor-pointer"
                                      : "text-on-surface-variant/25 pointer-events-none",
                                )}
                              >
                                <div
                                  className={cn(
                                    "w-7 h-7 flex items-center justify-center rounded-full border transition-all duration-300",
                                    isCurrent
                                      ? "border-primary bg-primary text-white"
                                      : isDone
                                        ? "border-primary/40 bg-primary/5 text-primary"
                                        : "border-outline-variant/40 text-on-surface-variant/30",
                                  )}
                                >
                                  {isDone ? (
                                    <Check size={12} strokeWidth={3} />
                                  ) : (
                                    <Icon size={13} />
                                  )}
                                </div>
                                <span className="font-body text-[11px] font-semibold uppercase tracking-[0.08em] hidden lg:block">
                                  {m.label}
                                </span>
                              </button>
                            );
                          })}
                        </div>
                        <button
                          onClick={onClose}
                          className="w-10 h-10 flex items-center justify-center text-on-surface-variant/50 hover:text-on-surface hover:bg-surface-container-high rounded-full transition-all duration-200 cursor-pointer"
                          aria-label="Close"
                        >
                          <X size={18} />
                        </button>
                      </div>

                      <div className="relative h-2px bg-surface-container-high">
                        <motion.div
                          className="absolute inset-y-0 left-0 bg-primary"
                          animate={{ width: `${(step / STEP_COUNT) * 100}%` }}
                          transition={{
                            type: "spring",
                            stiffness: 200,
                            damping: 28,
                          }}
                        />
                      </div>

                      <div className="mt-6 mb-1">
                        <h2 className="font-display text-headline-md max-md:text-headline-md-mobile text-on-surface">
                          {meta.heading}
                        </h2>
                        <p className="font-body text-sm text-on-surface-variant/60 mt-1">
                          {meta.subheading}
                        </p>
                      </div>
                    </div>

                    {/* Scrollable Content */}
                    <div
                      ref={scrollContainerRef}
                      data-lenis-prevent
                      className="flex-1 overflow-y-auto overscroll-contain min-h-0 px-8 lg:px-10 pb-8"
                    >
                      <div className="pt-6">{stepContent}</div>

                      {/* Inline Navigation */}
                      <div className="flex items-center gap-3 mt-8 pt-6 border-t border-outline-variant/30">
                        {step > 1 && (
                          <motion.button
                            initial={{ opacity: 0, x: -10 }}
                            animate={{ opacity: 1, x: 0 }}
                            whileTap={{ scale: 0.98 }}
                            onClick={goBack}
                            className="flex items-center gap-1.5 px-5 py-3 rounded-full border border-outline-variant/60 font-body text-[11px] font-semibold uppercase tracking-0.1em text-on-surface-variant hover:bg-surface-container-low transition-all duration-200 cursor-pointer"
                          >
                            <ChevronLeft size={14} />
                            Back
                          </motion.button>
                        )}
                        <div className="flex-1" />
                        {step < STEP_COUNT && (
                          <motion.button
                            whileHover={{ y: -1 }}
                            whileTap={{ scale: 0.98 }}
                            onClick={handleNext}
                            className={cn(
                              "px-8 py-3.5 rounded-full",
                              "bg-primary text-on-primary",
                              "font-body text-[11px] font-semibold uppercase tracking-0.1em",
                              "shadow-[0_2px_8px_rgba(0,71,171,0.25)]",
                              "hover:bg-primary-hover hover:shadow-[0_4px_16px_rgba(0,71,171,0.3)]",
                              "transition-all duration-300 cursor-pointer",
                            )}
                          >
                            Continue
                          </motion.button>
                        )}
                        {step === STEP_COUNT && (
                          <motion.button
                            whileHover={{ y: -1 }}
                            whileTap={{ scale: 0.98 }}
                            onClick={handleSubmit}
                            className={cn(
                              "inline-flex items-center gap-2.5 px-8 py-3.5 rounded-full",
                              "bg-primary text-on-primary",
                              "font-body text-[11px] font-semibold uppercase tracking-0.1em",
                              "shadow-[0_2px_8px_rgba(0,71,171,0.25)]",
                              "hover:bg-primary-hover hover:shadow-[0_4px_16px_rgba(0,71,171,0.3)]",
                              "transition-all duration-300 cursor-pointer",
                            )}
                          >
                            <Send size={13} />
                            Request Reservation
                          </motion.button>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* RIGHT — Sticky Summary */}
                  <div
                    data-lenis-prevent
                    className="w-340px lg:w-380px shrink-0 border-l border-outline-variant/30 bg-surface-container-low/50 overflow-y-auto overscroll-contain"
                  >
                    {summaryContent}
                  </div>
                </div>
              )}
            </motion.div>

            {/* ─── MOBILE BOTTOM SHEET ─── */}
            <motion.div
              variants={panelMobileVariants}
              initial="hidden"
              animate="visible"
              exit="exit"
              className={cn(
                "md:hidden fixed bottom-0 left-0 right-0 bg-white flex flex-col",
                "max-h-[95vh]",
              )}
              onClick={(e) => e.stopPropagation()}
              style={{ paddingBottom: "env(safe-area-inset-bottom, 0px)" }}
            >
              {submitState === "success" ? (
                <SuccessState
                  propertyName={property.name}
                  reservationId={reservationId}
                  onClose={onClose}
                />
              ) : submitState === "submitting" ? (
                <SubmittingState />
              ) : (
                <>
                  {/* Mobile Header */}
                  <div className="shrink-0 px-5 pt-4 pb-0">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-1.5">
                        {STEP_META.map((m, i) => {
                          const isCurrent = i + 1 === step;
                          const isDone = i + 1 < step;
                          return (
                            <div
                              key={m.label}
                              className={cn(
                                "h-1 rounded-full transition-all duration-500",
                                isCurrent
                                  ? "w-6 bg-primary"
                                  : isDone
                                    ? "w-3 bg-primary/40"
                                    : "w-3 bg-outline-variant/40",
                              )}
                            />
                          );
                        })}
                      </div>
                      <button
                        onClick={onClose}
                        className="w-11 h-11 flex items-center justify-center text-on-surface-variant/50 hover:text-on-surface rounded-full transition-colors duration-200 cursor-pointer"
                        aria-label="Close"
                      >
                        <X size={20} />
                      </button>
                    </div>
                    <h2 className="font-display text-headline-sm text-on-surface">
                      {meta.heading}
                    </h2>
                    <p className="font-body text-xs text-on-surface-variant/60 mt-0.5">
                      {meta.subheading}
                    </p>
                  </div>

                  {/* Mobile Scrollable Content */}
                  <div
                    data-lenis-prevent
                    className="flex-1 overflow-y-auto overscroll-contain min-h-0 px-5 py-5"
                  >
                    {stepContent}
                  </div>

                  {/* Mobile Bottom Bar */}
                  <div className="shrink-0 px-5 py-3.5 border-t border-outline-variant/30 bg-white pb-[calc(14px+env(safe-area-inset-bottom,0px))]">
                    <div className="flex items-center gap-3">
                      {step > 1 && (
                        <button
                          onClick={goBack}
                          className="flex items-center gap-1 px-4 py-3 rounded-full border border-outline-variant/60 font-body text-[11px] font-semibold uppercase tracking-0.1em text-on-surface-variant cursor-pointer"
                        >
                          <ChevronLeft size={14} />
                          Back
                        </button>
                      )}
                      <div className="flex-1" />
                      {step < STEP_COUNT ? (
                        <button
                          onClick={handleNext}
                          className={cn(
                            "px-6 py-3.5 rounded-full",
                            "bg-primary text-on-primary",
                            "font-body text-[11px] font-semibold uppercase tracking-0.1em",
                            "shadow-[0_2px_8px_rgba(0,71,171,0.25)]",
                            "transition-all duration-300 cursor-pointer",
                          )}
                        >
                          Continue
                        </button>
                      ) : (
                        <button
                          onClick={handleSubmit}
                          className={cn(
                            "inline-flex items-center gap-2 px-6 py-3.5 rounded-full",
                            "bg-primary text-on-primary",
                            "font-body text-[11px] font-semibold uppercase tracking-0.1em",
                            "shadow-[0_2px_8px_rgba(0,71,171,0.25)]",
                            "transition-all duration-300 cursor-pointer",
                          )}
                        >
                          <Send size={13} />
                          Request
                        </button>
                      )}
                    </div>
                    <div className="flex items-center justify-between mt-2.5 px-1">
                      <span className="font-body text-[11px] text-on-surface-variant/50">
                        Step {step} of {STEP_COUNT}
                      </span>
                      <motion.span
                        key={total}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="font-body text-sm font-semibold text-primary"
                      >
                        {formatPrice(total)}
                      </motion.span>
                    </div>
                  </div>
                </>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
      <TermsModal
        isOpen={termsOpen}
        onClose={() => setTermsOpen(false)}
        onAgree={() => handleConsentChange(true)}
        section={termsSection}
        reviewRequired
        triggerRef={termsSection === "privacy" ? privacyLinkRef : termsLinkRef}
      />
    </>
  );
}

function SummaryItem({
  label,
  value,
  icon,
  valueClassName,
}: {
  label: string;
  value: string;
  icon?: React.ReactNode;
  valueClassName?: string;
}) {
  return (
    <div className="flex justify-between items-center py-2.5">
      <span className="font-body text-[13px] text-on-surface-variant/60 flex items-center gap-2">
        {icon}
        {label}
      </span>
      <span
        className={cn(
          "font-body text-[13px] text-on-surface font-medium",
          valueClassName,
        )}
      >
        {value}
      </span>
    </div>
  );
}

/* ======================================================================
   SUBMITTING STATE
   ====================================================================== */
function SubmittingState() {
  return (
    <div className="flex-1 flex items-center justify-center p-12 min-h-400px">
      <div className="text-center">
        <svg
          className="animate-spin h-8 w-8 mx-auto mb-4 text-primary"
          viewBox="0 0 24 24"
          fill="none"
        >
          <circle
            className="opacity-25"
            cx="12"
            cy="12"
            r="10"
            stroke="currentColor"
            strokeWidth="4"
          />
          <path
            className="opacity-75"
            fill="currentColor"
            d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"
          />
        </svg>
        <p className="font-body text-sm text-on-surface-variant">
          Submitting your reservation request...
        </p>
      </div>
    </div>
  );
}

/* ======================================================================
   STEP 1 — Choose Your Stay Date
   ====================================================================== */
function StepDate({
  arrivalDate,
  arrivalTime,
  onArrivalDateChange,
  onArrivalTimeChange,
  dateError,
  timeError,
  fixedTime,
  fixedTimeLabel,
  unavailableDates,
  isTimeUnavailable,
  availabilityLoading,
  availabilityError,
}: {
  arrivalDate: string | null;
  arrivalTime: string | null;
  onArrivalDateChange: (date: string) => void;
  onArrivalTimeChange: (time: string) => void;
  dateError?: string;
  timeError?: string;
  fixedTime?: string;
  fixedTimeLabel?: string;
  unavailableDates: Set<string>;
  isTimeUnavailable: (time: string) => boolean;
  availabilityLoading: boolean;
  availabilityError: string;
}) {
  return (
    <div>
      <ArrivalDateTimePicker
        arrivalDate={arrivalDate}
        arrivalTime={arrivalTime}
        onArrivalDateChange={onArrivalDateChange}
        onArrivalTimeChange={onArrivalTimeChange}
        dateError={dateError}
        timeError={timeError}
        fixedTime={fixedTime}
        fixedTimeLabel={fixedTimeLabel}
        unavailableDates={unavailableDates}
        isTimeUnavailable={isTimeUnavailable}
        availabilityLoading={availabilityLoading}
        availabilityError={availabilityError}
      />

      <div className="mt-6 p-4 rounded-xl bg-tertiary-container/20 border border-tertiary/10">
        <div className="flex items-start gap-3">
          <Shield size={15} className="text-tertiary shrink-0 mt-0.5" />
          <div>
            <p className="font-body text-[13px] text-on-surface font-medium">
              One reservation per villa per date
            </p>
            <p className="font-body text-xs text-on-surface-variant/60 mt-0.5">
              Perfect for birthdays and family gatherings.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ======================================================================
   STEP 2 — Who's Joining Your Stay?
   ====================================================================== */
function StepGuests({
  maxGuests,
  villaName,
  guests,
  onChange,
  isKrib1,
}: {
  maxGuests: number;
  villaName: string;
  guests: GuestCount;
  onChange: (g: GuestCount) => void;
  isKrib1?: boolean;
}) {
  const totalGuests = guests.adults + guests.children;
  const isOver = isKrib1 && totalGuests > maxGuests;

  return (
    <div>
      <GuestSelector
        maxGuests={maxGuests}
        villaName={villaName}
        value={guests}
        onChange={onChange}
      />

      {guests.pets > 2 && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: "auto" }}
          className="mt-4 overflow-hidden"
        >
          <p className="font-body text-sm text-primary leading-relaxed">
            For more than 2 pets, our staff will be notified so we can prepare
            accordingly.
          </p>
        </motion.div>
      )}

      <div className="mt-8 p-4 rounded-xl bg-surface-container-low border border-outline-variant/20">
        <div className="flex items-start gap-3">
          <Sparkles size={15} className="text-secondary shrink-0 mt-0.5" />
          <div>
            {isKrib1 ? (
              <>
                <p className="font-body text-[13px] text-on-surface font-medium">
                  Standard capacity: {maxGuests} guests
                </p>
                <p className="font-body text-xs text-on-surface-variant/60 mt-0.5">
                  Additional guests can be requested at ₱200/person above{" "}
                  {maxGuests}. Requests above {maxGuests} guests require admin
                  approval.
                </p>
              </>
            ) : (
              <>
                <p className="font-body text-[13px] text-on-surface font-medium">
                  Maximum {maxGuests} guests allowed
                </p>
                <p className="font-body text-xs text-on-surface-variant/60 mt-0.5">
                  Adults and children count toward the guest limit. Infants and
                  pets do not.
                </p>
              </>
            )}
          </div>
        </div>
      </div>

      {isOver && (
        <div className="mt-4 p-4 rounded-xl bg-amber-50 border border-amber-200/60">
          <div className="flex items-start gap-3">
            <Sparkles size={15} className="text-amber-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-body text-[13px] text-amber-800 font-medium">
                More than {maxGuests} guests requires approval
              </p>
              <p className="font-body text-xs text-amber-700/80 mt-0.5">
                Additional guests are ₱200 per person. Our team will review your
                request before confirmation.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/* ======================================================================
   STEP 3 — A Few Details About You
   ====================================================================== */
function ConsentCheckbox({
  rowRef,
  checked,
  onChange,
  onOpenTerms,
  onOpenPrivacy,
  onOpenReview,
  termsLinkRef,
  privacyLinkRef,
  error,
}: {
  rowRef: React.RefObject<HTMLDivElement | null>;
  checked: boolean;
  onChange: (v: boolean) => void;
  onOpenTerms: () => void;
  onOpenPrivacy: () => void;
  onOpenReview: () => void;
  termsLinkRef: React.RefObject<HTMLButtonElement | null>;
  privacyLinkRef: React.RefObject<HTMLButtonElement | null>;
  error?: string;
}) {
  return (
    <div ref={rowRef}>
      <label className="flex items-start gap-3 cursor-pointer select-none group">
        <input
          type="checkbox"
          checked={checked}
          onClick={(e) => {
            if (!checked) {
              e.preventDefault();
              onOpenReview();
            }
          }}
          onChange={(e) => onChange(e.target.checked)}
          aria-describedby={error ? "consent-error" : undefined}
          aria-invalid={error ? true : undefined}
          className="peer sr-only"
        />
        <span
          aria-hidden="true"
          className={cn(
            "mt-0.5 shrink-0 w-4 h-4 rounded-[4px] border-[1.5px] flex items-center justify-center transition-all duration-200",
            checked
              ? "bg-primary border-primary"
              : error
                ? "border-error/60 group-hover:border-primary/60"
                : "border-on-surface-variant/40 group-hover:border-primary/60",
            "peer-focus-visible:ring-2 peer-focus-visible:ring-primary/30 peer-focus-visible:ring-offset-2 peer-focus-visible:ring-offset-white",
          )}
        >
          <svg
            width="10"
            height="10"
            viewBox="0 0 10 10"
            fill="none"
            className={cn(
              "transition-all duration-200",
              checked ? "opacity-100 scale-100" : "opacity-0 scale-75",
            )}
          >
            <path
              d="M1.5 5.5L3.75 7.75L8.5 2.5"
              stroke="white"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </span>
        <span className="font-body text-[13px] text-on-surface leading-relaxed">
          I agree to the{" "}
          <button
            ref={termsLinkRef}
            type="button"
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              onOpenTerms();
            }}
            className="text-primary font-medium underline underline-offset-2 rounded-sm hover:text-primary-hover transition-colors duration-200 cursor-pointer"
          >
            Terms &amp; Conditions
          </button>{" "}
          and{" "}
          <button
            ref={privacyLinkRef}
            type="button"
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              onOpenPrivacy();
            }}
            className="text-primary font-medium underline underline-offset-2 rounded-sm hover:text-primary-hover transition-colors duration-200 cursor-pointer"
          >
            Privacy Policy
          </button>
          .
        </span>
      </label>
      {error && (
        <p
          id="consent-error"
          className="font-body text-[11px] text-error mt-1.5 ml-7"
        >
          {error}
        </p>
      )}
    </div>
  );
}

function StepDetails({
  fullName,
  onFullNameChange,
  email,
  onEmailChange,
  phone,
  onPhoneChange,
  message,
  onMessageChange,
  consentAccepted,
  onConsentChange,
  onOpenTerms,
  onOpenPrivacy,
  onOpenReview,
  consentRowRef,
  termsLinkRef,
  privacyLinkRef,
  errors,
}: {
  fullName: string;
  onFullNameChange: (v: string) => void;
  email: string;
  onEmailChange: (v: string) => void;
  phone: string;
  onPhoneChange: (v: string) => void;
  message: string;
  onMessageChange: (v: string) => void;
  consentAccepted: boolean;
  onConsentChange: (v: boolean) => void;
  onOpenTerms: () => void;
  onOpenPrivacy: () => void;
  onOpenReview: () => void;
  consentRowRef: React.RefObject<HTMLDivElement | null>;
  termsLinkRef: React.RefObject<HTMLButtonElement | null>;
  privacyLinkRef: React.RefObject<HTMLButtonElement | null>;
  errors: Record<string, string>;
}) {
  const nameRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setTimeout(() => nameRef.current?.focus(), 350);
  }, []);

  return (
    <div className="space-y-5">
      <div>
        <label className="font-body text-[11px] text-on-surface-variant/60 uppercase tracking-[0.12em] font-semibold block mb-1.5">
          Full Name <span className="text-error">*</span>
        </label>
        <input
          ref={nameRef}
          type="text"
          value={fullName}
          onChange={(e) => onFullNameChange(e.target.value)}
          placeholder="Enter your full name"
          className="w-full px-4 py-3.5 rounded-lg bg-surface-container-low border border-outline-variant/60 font-body text-sm text-on-surface placeholder:text-on-surface-variant/30 focus:outline-none focus:border-primary transition-colors duration-200"
        />
        {errors.fullName && (
          <p className="font-body text-[11px] text-error mt-1">
            {errors.fullName}
          </p>
        )}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label className="font-body text-[11px] text-on-surface-variant/60 uppercase tracking-[0.12em] font-semibold block mb-1.5">
            Email Address <span className="text-error">*</span>
          </label>
          <input
            type="email"
            value={email}
            onChange={(e) => onEmailChange(e.target.value)}
            placeholder="you@email.com"
            className="w-full px-4 py-3.5 rounded-lg bg-surface-container-low border border-outline-variant/60 font-body text-sm text-on-surface placeholder:text-on-surface-variant/30 focus:outline-none focus:border-primary transition-colors duration-200"
          />
          {errors.email && (
            <p className="font-body text-[11px] text-error mt-1">
              {errors.email}
            </p>
          )}
        </div>
        <div>
          <label className="font-body text-[11px] text-on-surface-variant/60 uppercase tracking-[0.12em] font-semibold block mb-1.5">
            Phone Number <span className="text-error">*</span>
          </label>
          <input
            type="tel"
            value={phone}
            onChange={(e) => onPhoneChange(e.target.value)}
            placeholder="+63 9XX XXX XXXX"
            className="w-full px-4 py-3.5 rounded-lg bg-surface-container-low border border-outline-variant/60 font-body text-sm text-on-surface placeholder:text-on-surface-variant/30 focus:outline-none focus:border-primary transition-colors duration-200"
          />
          {errors.phone && (
            <p className="font-body text-[11px] text-error mt-1">
              {errors.phone}
            </p>
          )}
        </div>
      </div>

      <div>
        <label className="font-body text-[11px] text-on-surface-variant/60 uppercase tracking-[0.12em] font-semibold block mb-1.5">
          Special Requests{" "}
          <span className="text-on-surface-variant/30 normal-case font-normal">
            (Optional)
          </span>
        </label>
        <p className="font-body text-sm text-on-surface-variant mt-1 mb-2">
          Let us know if you have any special requests. We&apos;ll do our best
          to accommodate, but availability isn&apos;t guaranteed.
        </p>
        <textarea
          value={message}
          onChange={(e) => onMessageChange(e.target.value)}
          placeholder="Special requests, celebrations, dietary needs..."
          rows={3}
          className="w-full px-4 py-3.5 rounded-lg bg-surface-container-low border border-outline-variant/60 font-body text-sm text-on-surface placeholder:text-on-surface-variant/30 focus:outline-none focus:border-primary transition-colors duration-200 resize-none"
        />
      </div>

      <div className="pt-1 border-t border-outline-variant/30">
        <ConsentCheckbox
          rowRef={consentRowRef}
          checked={consentAccepted}
          onChange={onConsentChange}
          onOpenTerms={onOpenTerms}
          onOpenPrivacy={onOpenPrivacy}
          onOpenReview={onOpenReview}
          termsLinkRef={termsLinkRef}
          privacyLinkRef={privacyLinkRef}
          error={errors.consent}
        />
      </div>

      <div className="p-4 rounded-xl bg-tertiary-container/20 border border-tertiary/10">
        <p className="font-body text-xs text-on-surface-variant">
          No payment required until your reservation is approved. We&apos;ll
          personally review your request before any payment is processed.
        </p>
      </div>
    </div>
  );
}

/* ======================================================================
   STEP 4 — Review Your Reservation
   ====================================================================== */
function StepReview({
  property,
  arrivalDatetime,
  checkoutDatetime,
  guests,
  totalGuests,
  fullName,
  email,
  phone,
  message,
  basePrice,
  isKrib1,
  isParty,
  additionalGuestFee,
  partyFeeAmount,
  total,
  submitError,
  submitErrorRef,
}: {
  property: PropertyInfo;
  arrivalDatetime: string | null;
  checkoutDatetime: string | null;
  guests: GuestCount;
  totalGuests: number;
  fullName: string;
  email: string;
  phone: string;
  message: string;
  basePrice: number;
  isKrib1?: boolean;
  isParty?: boolean;
  additionalGuestFee?: number;
  partyFeeAmount?: number;
  total: number;
  submitError: string;
  submitErrorRef: React.RefObject<HTMLDivElement | null>;
}) {
  const isOver = isKrib1 && totalGuests > KRIB1_STANDARD_CAPACITY;

  return (
    <div>
      {submitError && (
        <div
          ref={submitErrorRef}
          role="alert"
          className="mb-5 p-4 rounded-xl bg-error/5 border border-error/20"
        >
          <p className="font-body text-[13px] text-error">{submitError}</p>
        </div>
      )}

      {isOver && (
        <div className="mb-5 p-4 rounded-xl bg-amber-50 border border-amber-200/60">
          <p className="font-body text-[13px] text-amber-800 font-medium">
            This reservation requires admin approval due to {totalGuests} guests
            (standard capacity is {KRIB1_STANDARD_CAPACITY}).
          </p>
          <p className="font-body text-xs text-amber-700/80 mt-1">
            Additional guests: {totalGuests - KRIB1_STANDARD_CAPACITY} × ₱200 =
            ₱{additionalGuestFee?.toLocaleString("en-PH")}
            {isParty ? ` + ₱5,000 party fee` : ""}
          </p>
        </div>
      )}

      <div className="space-y-0">
        <ReviewRow label="Villa" value={property.name} />
        {arrivalDatetime && (
          <ReviewRow
            label="Arrival"
            value={formatArrivalLabel(arrivalDatetime)}
          />
        )}
        {checkoutDatetime && (
          <ReviewRow
            label="Checkout"
            value={formatCheckoutLabel(checkoutDatetime)}
            valueIcon={<Clock size={12} className="text-primary" />}
          />
        )}
        <ReviewRow
          label="Stay"
          value="21 Hours"
          valueIcon={<Clock size={12} className="text-primary" />}
        />
        <ReviewRow
          label="Guests"
          value={`${totalGuests} ${totalGuests === 1 ? "Guest" : "Guests"} (${guests.adults} Adult${guests.adults !== 1 ? "s" : ""}${guests.children > 0 ? `, ${guests.children} Child${guests.children !== 1 ? "ren" : ""}` : ""})`}
        />
        {guests.infants > 0 && (
          <ReviewRow label="Infants" value={`${guests.infants}`} />
        )}
        {guests.pets > 0 && <ReviewRow label="Pets" value={`${guests.pets}`} />}
        {isParty && isKrib1 && (
          <ReviewRow label="Event" value="Party / Event" />
        )}
      </div>

      <div className="h-px bg-outline-variant/30 my-5" />

      <div className="space-y-0">
        <p className="font-body text-[11px] text-on-surface-variant/50 uppercase tracking-[0.12em] font-semibold mb-3">
          Contact
        </p>
        <ReviewRow label="Name" value={fullName} />
        <ReviewRow label="Email" value={email} />
        <ReviewRow label="Phone" value={phone} />
        {message && <ReviewRow label="Message" value={message} />}
      </div>

      <div className="h-px bg-outline-variant/30 my-5" />

      <div className="space-y-0">
        <p className="font-body text-[11px] text-on-surface-variant/50 uppercase tracking-[0.12em] font-semibold mb-3">
          Pricing
        </p>
        <ReviewRow label="Base Rate" value={formatPrice(basePrice)} />

        {isOver && additionalGuestFee && additionalGuestFee > 0 && (
          <ReviewRow
            label={`Additional guests (${totalGuests - KRIB1_STANDARD_CAPACITY} × ₱200)`}
            value={formatPrice(additionalGuestFee)}
          />
        )}

        {isParty && isKrib1 && (
          <ReviewRow
            label="Party / Event Fee"
            value={formatPrice(partyFeeAmount ?? 5000)}
          />
        )}

        <div className="flex justify-between items-baseline pt-4 border-t border-on-surface/10">
          <span className="font-body text-sm font-semibold text-on-surface">
            Total
          </span>
          <motion.span
            key={total}
            initial={{ opacity: 0, y: 4 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
            className="font-display text-headline-md font-medium text-primary"
          >
            {formatPrice(total)}
          </motion.span>
        </div>
      </div>

      <div className="mt-6 p-4 rounded-xl bg-primary-container/20 border border-primary/10">
        <div className="flex items-start gap-3">
          <Shield size={14} className="text-primary shrink-0 mt-0.5" />
          <div>
            <p className="font-body text-[13px] text-on-surface font-medium">
              We&apos;ll personally review your request
            </p>
            <p className="font-body text-xs text-on-surface-variant/60 mt-0.5">
              No payment is required until your reservation has been approved by
              our team.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

function ReviewRow({
  label,
  value,
  valueIcon,
}: {
  label: string;
  value: string;
  valueIcon?: React.ReactNode;
}) {
  return (
    <div className="flex justify-between items-start gap-4 py-2">
      <span className="font-body text-[13px] text-on-surface-variant shrink-0">
        {label}
      </span>
      <span className="font-body text-[13px] text-on-surface font-medium text-right flex items-center gap-1.5">
        {valueIcon}
        {value}
      </span>
    </div>
  );
}

/* ======================================================================
   SUCCESS STATE
   ====================================================================== */
function SuccessState({
  propertyName,
  reservationId,
  onClose,
}: {
  propertyName: string;
  reservationId: string;
  onClose: () => void;
}) {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(reservationId).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
      className="flex-1 flex items-center justify-center p-8 sm:p-10"
    >
      <div className="text-center max-w-md">
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ duration: 0.5, delay: 0.15, ease: [0.22, 1, 0.36, 1] }}
          className="w-16 h-16 rounded-full bg-tertiary-container flex items-center justify-center mb-6 mx-auto"
        >
          <Check size={28} className="text-tertiary" strokeWidth={2.5} />
        </motion.div>

        <motion.h2
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.3 }}
          className="font-display text-headline-xl max-md:text-headline-xl-mobile text-on-surface mb-3"
        >
          You&apos;re almost there!
        </motion.h2>

        <motion.p
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.4 }}
          className="font-body text-sm text-on-surface-variant leading-relaxed mb-4"
        >
          We&apos;ve received your reservation request for{" "}
          <strong className="text-on-surface">{propertyName}</strong>.
        </motion.p>

        <motion.p
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.45 }}
          className="font-body text-sm text-on-surface-variant leading-relaxed mb-8"
        >
          Our team will review your preferred date shortly. You&apos;ll receive
          confirmation once your reservation has been approved.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.5 }}
          className="mb-8"
        >
          <p className="font-body text-[10px] text-on-surface-variant/50 uppercase tracking-[0.15em] font-semibold mb-2">
            Reservation ID
          </p>
          <div className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-surface-container-low border border-outline-variant/30">
            <code className="font-mono text-sm font-semibold text-on-surface tracking-tight">
              {reservationId}
            </code>
            <button
              type="button"
              onClick={handleCopy}
              className="w-8 h-8 flex items-center justify-center rounded hover:bg-outline-variant/30 transition-colors cursor-pointer"
              aria-label="Copy reservation ID"
            >
              {copied ? (
                <Check size={13} className="text-tertiary" />
              ) : (
                <span className="font-body text-[10px] text-primary font-semibold">
                  Copy
                </span>
              )}
            </button>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.6 }}
        >
          <button
            type="button"
            onClick={() => {
              onClose();
              window.location.href = "/my-reservation";
            }}
            className="inline-flex items-center gap-2.5 px-8 py-4 rounded-full bg-primary text-on-primary font-body text-[11px] font-semibold uppercase tracking-0.1em shadow-[0_2px_8px_rgba(0,71,171,0.25)] hover:bg-primary-hover transition-all duration-300 cursor-pointer"
          >
            View My Reservation <ArrowRight size={14} />
          </button>
        </motion.div>
      </div>
    </motion.div>
  );
}
